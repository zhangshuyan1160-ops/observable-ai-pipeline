"""Fixed, versioned pipeline handlers."""
